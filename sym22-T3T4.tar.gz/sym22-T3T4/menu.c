#include <stdio.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>

#include "gameinfo.h"
#include "menu.h"

const char *lines[3] = {
    "SinglePlayer",
    "MultiPlayer",
    "Quit"
};

menu *menuCreate() {
    menu *ret_menu = (menu*) malloc(sizeof(menu));
    if (!ret_menu)
        return NULL;
    
    ret_menu->option = 0;
    ret_menu->close = 0;
    ret_menu->switchImgTitle = 0;
    ret_menu->switchP1_box = 0;
    ret_menu->switchP2_box = 0;
    ret_menu->switchMap = 0;
    ret_menu->p1_CharConfirmed = 0;
    ret_menu->p2_CharConfirmed = 0;
    ret_menu->mapsPlaced = 0;
    ret_menu->mapConfirmed = 0;
    ret_menu->ryuMenu = al_load_bitmap("./img/menu/ryuMenu.png");
    ret_menu->chunliMenu = al_load_bitmap("./img/menu/chunliMenu.png");
    ret_menu->blankaMenu = al_load_bitmap("./img/menu/blankaMenu.png");
    ret_menu->zangiefMenu = al_load_bitmap("./img/menu/zangiefMenu.png");

    return ret_menu;
}

void runMainMenu(menu *menu, gameStatus *gameStatus) {
    ALLEGRO_COLOR baseFontColor = al_map_rgb(255, 255, 255);
    ALLEGRO_COLOR selectedFontColor = al_map_rgb(255, 255, 0);

    int titleImgW = al_get_bitmap_width (gameStatus->TitleImg);
    int titleImgH = al_get_bitmap_height (gameStatus->TitleImg);

    int x1 = X_SCREEN/2 - 200;
    int w = 400;
    int y1 = 0;
    int h = 350;

    al_draw_scaled_bitmap(gameStatus->TitleImg, 0, 0, titleImgW, titleImgH, x1, y1, w, h, 0);
    
    al_draw_text (gameStatus->font, al_map_rgb(100, 100, 100), X_SCREEN / 2, (Y_SCREEN / 2) + 50, ALLEGRO_ALIGN_CENTRE, lines[0]);
    if (menu->option == 0)
        al_draw_text (gameStatus->font, selectedFontColor, X_SCREEN / 2, (Y_SCREEN / 2) + 100, ALLEGRO_ALIGN_CENTRE, lines[1]);
    else
        al_draw_text (gameStatus->font, baseFontColor, X_SCREEN / 2, (Y_SCREEN / 2) + 100, ALLEGRO_ALIGN_CENTRE, lines[1]);
    
    if (menu->option == 1)
        al_draw_text (gameStatus->font, selectedFontColor, X_SCREEN / 2, (Y_SCREEN / 2) + 150, ALLEGRO_ALIGN_CENTRE, lines[2]);
    else
        al_draw_text (gameStatus->font, baseFontColor, X_SCREEN / 2, (Y_SCREEN / 2) + 150, ALLEGRO_ALIGN_CENTRE, lines[2]);
}

void runCharSelecMenu(player *p1, player *p2, menu *menu, gameStatus *gameStatus) {
    ALLEGRO_COLOR selecBoxColor = al_map_rgb (255,255,0);
    int p1selecBoxX = 0;
    int p2selecBoxX = 0;
    int selecBoxY = Y_SCREEN - 200;
    int selecBoxSide = 100;

    int charImgW = al_get_bitmap_width (menu->ryuMenu);
    int charImgH = al_get_bitmap_height (menu->ryuMenu);

    al_draw_text (gameStatus->font, al_map_rgb(255,255,255), X_SCREEN / 2, (Y_SCREEN / 2) - 100, ALLEGRO_ALIGN_CENTRE, "Selecione o personagem");
    
    al_convert_mask_to_alpha(menu->ryuMenu, al_get_pixel(menu->ryuMenu, 0, 0));
    al_convert_mask_to_alpha(menu->chunliMenu, al_get_pixel(menu->chunliMenu, 0, 0));
    al_convert_mask_to_alpha(menu->blankaMenu, al_get_pixel(menu->blankaMenu, 0, 0));
    al_convert_mask_to_alpha(menu->zangiefMenu, al_get_pixel(menu->zangiefMenu, 0, 0));

    al_draw_scaled_bitmap(menu->ryuMenu, 0, 0, charImgW, charImgH, (X_SCREEN/2) - 275, selecBoxY, selecBoxSide, selecBoxSide, 0);
    al_draw_scaled_bitmap(menu->chunliMenu, 0, 0, charImgW, charImgH, (X_SCREEN/2) - 125, selecBoxY, selecBoxSide, selecBoxSide, 0);
    al_draw_scaled_bitmap(menu->blankaMenu, 0, 0, charImgW, charImgH, (X_SCREEN/2) + 25, selecBoxY, selecBoxSide, selecBoxSide, 0);
    al_draw_scaled_bitmap(menu->zangiefMenu, 0, 0, charImgW, charImgH, (X_SCREEN/2) + 175, selecBoxY, selecBoxSide, selecBoxSide, 0);
    switch (p1->character_id) {
        case 0:
            p1selecBoxX = (X_SCREEN/2) - 275;
            break;
        case 1:
            p1selecBoxX = (X_SCREEN/2) - 125;
            break;
        case 2:
            p1selecBoxX = (X_SCREEN/2) + 25;
            break;
        case 3:
            p1selecBoxX = (X_SCREEN/2) + 175;
            break;
    }
    switch (p2->character_id) {
        case 4:
            p2selecBoxX = (X_SCREEN/2) - 275;
            break;
        case 5:
            p2selecBoxX = (X_SCREEN/2) - 125;
            break;
        case 6:
            p2selecBoxX = (X_SCREEN/2) + 25;
            break;
        case 7:
            p2selecBoxX = (X_SCREEN/2) + 175;
            break;
    }


    if (menu->switchP1_box || menu->p1_CharConfirmed){
        al_draw_rectangle(p1selecBoxX, selecBoxY, p1selecBoxX + selecBoxSide, selecBoxY + selecBoxSide, selecBoxColor, 2);
        menu->switchP1_box = 0;
    } else
        menu->switchP1_box = 1;

    if (menu->switchP2_box || menu->p2_CharConfirmed){
        al_draw_rectangle(p2selecBoxX, selecBoxY, p2selecBoxX + selecBoxSide, selecBoxY + selecBoxSide, selecBoxColor, 2);
        menu->switchP2_box = 0;
    } else
        menu->switchP2_box = 1;

    if (menu->p1_CharConfirmed && menu->p2_CharConfirmed)
        gameStatus->gameScene++;
}

void runMapSelecMenu(menu *menu, gameStatus *gameStatus) {
    ALLEGRO_COLOR selecBoxColor = al_map_rgb (255,255,0);
    ALLEGRO_BITMAP *stageThumb;
    int boxSelW = 400;
    int boxSelH = 300;
    int boxSelX = 200;
    int boxSelY = 250;
    int stageThumbW;
    int stageThumbH;
    char *stagePath;

    al_draw_text (gameStatus->font, al_map_rgb(255,255,255), X_SCREEN / 2, 150, ALLEGRO_ALIGN_CENTRE, "Selecione o mapa");

    if (menu->option == 0) {
        stagePath = "./img/stages/stage1.jpg";
    }
    if (menu->option == 1) {
        stagePath = "./img/stages/stage2.png";
    }
    if (menu->option == 2) {
        stagePath = "./img/stages/stage3.png";
    }
    stageThumb = al_load_bitmap(stagePath);
    stageThumbW = al_get_bitmap_width (stageThumb);
    stageThumbH = al_get_bitmap_height (stageThumb);

    al_draw_scaled_bitmap(stageThumb, 0, 0, stageThumbW, stageThumbH, boxSelX, boxSelY, boxSelW, boxSelH, 0);

    if (menu->switchMap || menu->mapConfirmed){
        al_draw_rectangle(boxSelX, boxSelY, boxSelX + boxSelW, boxSelY + boxSelH, selecBoxColor, 2);
        menu->switchMap = 0;
    } else
        menu->switchMap = 1;

    if (menu->mapConfirmed) {
        gameStatus->BGimg = al_load_bitmap(stagePath);
        gameStatus->gameScene++;
        al_rest(0.5);
    }
}

void runEndGame (player *p1, player *p2) {
    ALLEGRO_FONT *text = al_load_ttf_font("./pixelFont.ttf", 24, 0);
    al_clear_to_color(al_map_rgb(0,0,0));

    if (p1->roundWin == 2)
        al_draw_text (text, al_map_rgb(255,0,0), X_SCREEN/2+2, Y_SCREEN/2, ALLEGRO_ALIGN_CENTRE, "P1 VENCEU!");
    else 
        al_draw_text (text, al_map_rgb(0,0,255), X_SCREEN/2+2, Y_SCREEN/2, ALLEGRO_ALIGN_CENTRE, "P2 VENCEU!");

    al_destroy_font(text);
}

void menuDestroy(menu *menu) {
    if (menu) {
        al_destroy_bitmap(menu->ryuMenu);
        al_destroy_bitmap(menu->chunliMenu);
        al_destroy_bitmap(menu->blankaMenu);
        al_destroy_bitmap(menu->zangiefMenu);
        free (menu);
    }
}