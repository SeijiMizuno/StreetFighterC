#include <stdio.h>
#include <stdlib.h>

#include "player.h"
#include "hitbox.h"
#include "joystick.h"
#include "gameinfo.h"

player *playerCreate (unsigned short init_x, unsigned short init_y, unsigned short widht, unsigned short height) {
    player *ret_player = (player*) malloc(sizeof(player));
    if (!ret_player)
        return NULL;

    ret_player->combo = (int*) malloc(MAX_COMBO_KEY * sizeof(int));
    if (!ret_player->combo)
        return NULL;

    for (int i = 0; i < MAX_COMBO_KEY; i++)
        ret_player->combo[i] = 0;
    
    ret_player->character_id = 0;
    ret_player->hp = LIFEBAR_W;
    ret_player->vx = 0;
    ret_player->vy = 0;
    ret_player->onGround = 1;
    ret_player->isCrouch = 0;
    ret_player->airStun = 0;
    ret_player->roundWin = 0;
    ret_player->isDamaged = 0;
    ret_player->atkHitboxTick = 0;
    ret_player->atkCooldown = 0;
    ret_player->comboCooldown = 0;
    ret_player->isHuman = 1;
    ret_player->facing = 0;
    ret_player->comboSuccess = 0;
    ret_player->comboIndex = 0;
    ret_player->comboTimeElapsed = 0;
    ret_player->comboDamage = 0;
    ret_player->isAnimating = 0;
    ret_player->currentAnimation = IDLE;
    ret_player->bitmapScale = 0;
    ret_player->action = joystickCreate();
    ret_player->bodyHitbox = hitboxCreate(init_x, init_y, widht, height);
    ret_player->atkHitbox = hitboxCreate(0,0,0,0);
    ret_player->comboHitbox = hitboxCreate(0,0,0,0);

    return ret_player;
}

void initAnimation (animation *animation, ALLEGRO_BITMAP **frames, int numFrames, int duration) {
    animation->frames = malloc(numFrames * sizeof(ALLEGRO_BITMAP *));
    if (!animation->frames)
        exit(1);

    // Copia os ponteiros dos frames para a nova alocação
    for (int i = 0; i < numFrames; i++) {
        animation->frames[i] = frames[i];
    }

    animation->numFrames = numFrames;
    animation->currentFrame = 0;
    animation->frameDelay = duration;
    animation->frameDelayCounter = 0;
}

ALLEGRO_BITMAP *loadFrame (int numFrames, char *basePath, char *charState, int frameId) {
    char path[150];
    sprintf(path, "%s/%s/%s_%d.png", basePath, charState, charState, frameId);
    printf("%s\n", path);
    ALLEGRO_BITMAP *ret_frame = al_load_bitmap (path);
    if (!ret_frame) {
        fprintf(stderr, "FALHA em load_bitmap %s.\n", path);
        exit(1);
    }

    al_convert_mask_to_alpha(ret_frame, al_get_pixel(ret_frame, 0, 0));
    

    return ret_frame;
}

void loadPlayersChar (player *p) {
    char *basePath;
    if (p->character_id == 0 || p->character_id == 4) {
        p->bitmapScale = 2;
        basePath = "./img/ryu";
    }
    if (p->character_id == 1 || p->character_id == 5) {
        p->bitmapScale = 2;
        basePath = "./img/chunli";
    }
    if (p->character_id == 2 || p->character_id == 6) {
        p->bitmapScale = 1.75;
        basePath = "./img/blanka";
    }
    if (p->character_id == 3 || p->character_id == 7) {
        p->bitmapScale = 1.7;
        basePath = "./img/zangief";
    }

// Aloca memória dinâmica para os frames da animação
    ALLEGRO_BITMAP **idle = malloc(NUM_FRAMES_IDLE * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **walking = malloc(NUM_FRAMES_WALKING * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **lpunch = malloc(NUM_FRAMES_PUNCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **hpunch = malloc(NUM_FRAMES_PUNCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **jump = malloc(NUM_FRAMES_JUMP * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **jump_forward = malloc(NUM_FRAMES_JUMP * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **jump_backward = malloc(NUM_FRAMES_JUMP * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **jump_punch = malloc(NUM_FRAMES_JUMP_PUNCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **jump_kick = malloc(NUM_FRAMES_JUMP_KICK * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **lkick = malloc(NUM_FRAMES_LKICK * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **hkick = malloc(NUM_FRAMES_HKICK * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **crouch = malloc(NUM_FRAMES_CROUCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **crouch_lpunch = malloc(NUM_FRAMES_CROUCH_PUNCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **crouch_hpunch = malloc(NUM_FRAMES_CROUCH_PUNCH * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **crouch_lkick = malloc(NUM_FRAMES_CROUCH_KICK * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **crouch_hkick = malloc(NUM_FRAMES_CROUCH_KICK * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **hit = malloc(NUM_FRAMES_HIT * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **special_move = malloc(NUM_FRAMES_SPECIAL_MOVE * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **win = malloc(NUM_FRAMES_END_ROUND * sizeof(ALLEGRO_BITMAP *));
    ALLEGRO_BITMAP **lose = malloc(NUM_FRAMES_END_ROUND * sizeof(ALLEGRO_BITMAP *));

    for (int i = 0; i < NUM_FRAMES_IDLE; i++)
        idle[i] = loadFrame(NUM_FRAMES_IDLE, basePath, "idle", i + 1);
    
    for (int i = 0; i < NUM_FRAMES_WALKING; i++)
        walking[i] = loadFrame(NUM_FRAMES_WALKING, basePath, "walking", i + 1);

    for (int i = 0; i < NUM_FRAMES_PUNCH; i++)
        lpunch[i] = loadFrame(NUM_FRAMES_PUNCH, basePath, "lpunch", i + 1);

    for (int i = 0; i < NUM_FRAMES_PUNCH; i++)
        hpunch[i] = loadFrame(NUM_FRAMES_PUNCH, basePath, "hpunch", i + 1);
        
    for (int i = 0; i < NUM_FRAMES_JUMP; i++)
        jump[i] = loadFrame(NUM_FRAMES_JUMP, basePath, "jump", i + 1);

    for (int i = 0; i < NUM_FRAMES_JUMP; i++)
        jump_forward[i] = loadFrame(NUM_FRAMES_JUMP, basePath, "jump_forward", i + 1);

    for (int i = 0; i < NUM_FRAMES_JUMP; i++)
        jump_backward[i] = loadFrame(NUM_FRAMES_JUMP, basePath, "jump_backward", i + 1);

    for (int i = 0; i < NUM_FRAMES_JUMP_PUNCH; i++)
        jump_punch[i] = loadFrame(NUM_FRAMES_JUMP_PUNCH, basePath, "jump_punch", i + 1);

    for (int i = 0; i < NUM_FRAMES_JUMP_KICK; i++)
        jump_kick[i] = loadFrame(NUM_FRAMES_JUMP_KICK, basePath, "jump_kick", i + 1);

    for (int i = 0; i < NUM_FRAMES_LKICK; i++)
        lkick[i] = loadFrame(NUM_FRAMES_LKICK, basePath, "lkick", i + 1);

    for (int i = 0; i < NUM_FRAMES_HKICK; i++)
        hkick[i] = loadFrame(NUM_FRAMES_HKICK, basePath, "hkick", i + 1);

    for (int i = 0; i < NUM_FRAMES_CROUCH; i++)
        crouch[i] = loadFrame(NUM_FRAMES_CROUCH, basePath, "crouch", i + 1);

    for (int i = 0; i < NUM_FRAMES_CROUCH_PUNCH; i++)
        crouch_lpunch[i] = loadFrame(NUM_FRAMES_CROUCH_PUNCH, basePath, "crouch_lpunch", i + 1);
    
    for (int i = 0; i < NUM_FRAMES_CROUCH_PUNCH; i++)
        crouch_hpunch[i] = loadFrame(NUM_FRAMES_CROUCH_PUNCH, basePath, "crouch_hpunch", i + 1);

    for (int i = 0; i < NUM_FRAMES_LKICK; i++)
        crouch_lkick[i] = loadFrame(NUM_FRAMES_LKICK, basePath, "crouch_lkick", i + 1);

    for (int i = 0; i < NUM_FRAMES_CROUCH_KICK; i++)
        crouch_hkick[i] = loadFrame(NUM_FRAMES_CROUCH_KICK, basePath, "crouch_hkick", i + 1);

    for (int i = 0; i < NUM_FRAMES_HIT; i++)
        hit[i] = loadFrame(NUM_FRAMES_HIT, basePath, "hit", i + 1);

    for (int i = 0; i < NUM_FRAMES_SPECIAL_MOVE; i++)
        special_move[i] = loadFrame(NUM_FRAMES_SPECIAL_MOVE, basePath, "special_move", i + 1);

    for (int i = 0; i < NUM_FRAMES_END_ROUND; i++)
        win[i] = loadFrame(NUM_FRAMES_END_ROUND, basePath, "win", i + 1);

    for (int i = 0; i < NUM_FRAMES_END_ROUND; i++)
        lose[i] = loadFrame(NUM_FRAMES_END_ROUND, basePath, "lose", i + 1);

    // Inicializa a animação com os frames carregados
    initAnimation(&p->playerAnimation[IDLE], idle, NUM_FRAMES_IDLE, 5);
    initAnimation(&p->playerAnimation[WALKING], walking, NUM_FRAMES_WALKING, 3);
    initAnimation(&p->playerAnimation[LPUNCH], lpunch, NUM_FRAMES_PUNCH, 4);
    initAnimation(&p->playerAnimation[HPUNCH], hpunch, NUM_FRAMES_PUNCH, 4);
    initAnimation(&p->playerAnimation[JUMP], jump, NUM_FRAMES_JUMP, 3);
    initAnimation(&p->playerAnimation[JUMP_FORWARD], jump_forward, NUM_FRAMES_JUMP, 4);
    initAnimation(&p->playerAnimation[JUMP_BACKWARD], jump_backward, NUM_FRAMES_JUMP, 4);
    initAnimation(&p->playerAnimation[JUMP_PUNCH], jump_punch, NUM_FRAMES_JUMP_PUNCH, 4);
    initAnimation(&p->playerAnimation[JUMP_KICK], jump_kick, NUM_FRAMES_JUMP_KICK, 4);
    initAnimation(&p->playerAnimation[LKICK], lkick, NUM_FRAMES_LKICK, 4);
    initAnimation(&p->playerAnimation[HKICK], hkick, NUM_FRAMES_HKICK, 3);
    initAnimation(&p->playerAnimation[CROUCH], crouch, NUM_FRAMES_CROUCH, 1);
    initAnimation(&p->playerAnimation[CROUCH_LPUNCH], crouch_lpunch, NUM_FRAMES_CROUCH_PUNCH, 5);
    initAnimation(&p->playerAnimation[CROUCH_HPUNCH], crouch_hpunch, NUM_FRAMES_CROUCH_PUNCH, 5);
    initAnimation(&p->playerAnimation[CROUCH_LKICK], crouch_lkick, NUM_FRAMES_CROUCH_KICK, 4);
    initAnimation(&p->playerAnimation[CROUCH_HKICK], crouch_hkick, NUM_FRAMES_CROUCH_KICK, 4);
    initAnimation(&p->playerAnimation[HIT], hit, NUM_FRAMES_HIT, 1);
    initAnimation(&p->playerAnimation[SPECIAL_MOVE], special_move, NUM_FRAMES_SPECIAL_MOVE, 2);
    initAnimation(&p->playerAnimation[WIN], win, NUM_FRAMES_END_ROUND, 1000);
    initAnimation(&p->playerAnimation[LOSE], lose, NUM_FRAMES_END_ROUND, 1000);

    free(idle);
    free(walking);
    free(lpunch);
    free(hpunch);
    free(jump);
    free(jump_forward);
    free(jump_backward);
    free(jump_punch);
    free(jump_kick);
    free(lkick);
    free(hkick);
    free(crouch);
    free(crouch_lpunch);
    free(crouch_hpunch);
    free(crouch_lkick);
    free(crouch_hkick);
    free(hit);
    free(special_move);
    free(win);
    free(lose);
    
    p->currentAnimation = IDLE;
}

// sequencia de teclas necessárias quando facing == 0
const int COMBO_SEQUENCES_0[MAX_COMBOS][MAX_COMBO_KEY] = {
    //ryu combo
    // down -> right -> right -> right -> LP -> Down -> Left -> HP
    // p1
    {19, 4, 4, 4, 21, 19, 1, 9, 0, 0, 0, 0, 0, 0, 0},   

    // chun li combo
    // left -> right -> left -> right -> left -> right -> LK -> HK
    // p1
    {1, 4, 1, 4, 1, 4, 10, 11, 0, 0, 0, 0, 0, 0, 0},   

    // blanka combo
    // down -> right -> down -> down -> LP -> HP -> LK -> HK
    // p1
    {19, 4, 19, 19, 21, 9, 10, 11, 0, 0, 0, 0, 0, 0, 0},   

    // zangief combo
    // up -> down -> right -> down -> down -> left -> right -> HP
    // p1
    {23, 19, 4, 19, 19, 1, 4, 9, 0, 0, 0, 0, 0, 0, 0},


    //ryu combo
    // down -> right -> right -> right -> LP -> Down -> Left -> HP
    // p2
    {85, 83, 83, 83, 42, 85, 82, 43, 0, 0, 0, 0, 0, 0, 0},   

    // chun li combo
    // left -> right -> left -> right -> left -> right -> LK -> HK
    // p2
    {82, 83, 82, 83, 82, 83, 39, 40, 0, 0, 0, 0, 0, 0, 0},   

    // blanka combo
    // down -> right -> down -> down -> LP -> HP -> LK -> HK
    // p2
    {85, 83, 85, 85, 42, 43, 39, 40, 0, 0, 0, 0, 0, 0},   

    // zangief combo
    // up -> down -> right -> down -> down -> left -> right -> HP
    // p2
    {84, 85, 83, 85, 85, 82, 83, 43, 0, 0, 0, 0, 0, 0, 0}
};

// sequencia de teclas necessárias quando facing == 1
const int COMBO_SEQUENCES_1[MAX_COMBOS][MAX_COMBO_KEY] = {
    // ryu combo
    // down -> left -> left -> left -> LP -> down -> right -> HP
    // p1
    {19, 1, 1, 1, 21, 19, 4, 9, 0, 0, 0, 0, 0, 0, 0},   
    
    // chun li combo
    // right -> left -> right -> left -> right -> left -> LK -> HK
    // p1
    {4, 1, 4, 1, 4, 1, 10, 11, 0, 0, 0, 0, 0, 0, 0},   
    
    // blanka combo
    // down -> left -> down -> down -> LP -> HP -> LK -> HK
    // p1
    {19, 1, 19, 19, 21, 9, 10, 11, 0, 0, 0, 0, 0, 0, 0},   
    
    // zangief combo
    // up -> down -> left -> down -> down -> right -> left -> HP
    // p1
    {23, 19, 1, 19, 19, 4, 1, 9, 0, 0, 0, 0, 0, 0, 0},


    // ryu combo
    // down -> left -> left -> left -> LP -> down -> right -> HP
    // p2
    {85, 82, 82, 82, 42, 85, 83, 43, 0, 0, 0, 0, 0, 0, 0},   
    
    // chun li combo
    // right -> left -> right -> left -> right -> left -> LK -> HK
    // p2
    {83, 82, 83, 82, 83, 82, 39, 40, 0, 0, 0, 0, 0, 0, 0},   

    // blanka combo
    // down -> left -> down -> down -> LP -> HP -> LK -> HK
    // p2
    {85, 82, 85, 85, 42, 43, 39, 40, 0, 0, 0, 0, 0, 0},   
    
    // zangief combo
    // up -> down -> left -> down -> down -> right -> left -> HP
    // p2
    {84, 85, 82, 85, 85, 83, 82, 43, 0, 0, 0, 0, 0, 0, 0}
};

void toggleState (unsigned char *toBeToggled) {
    *toBeToggled = !(*toBeToggled);
}

void setAtkCooldown (player *player) {
    if (player->atkCooldown == 0) 
        player->atkCooldown = ATK_COOLDOWN;
}

void setAtkHitbox (player *element) {
    // para simplificar os textos
    unsigned short p_y1;
    unsigned short k_y1;

    if (element->atkHitboxTick == 0) {    
        // decisão da posição y1 do ataque
        if (!element->onGround) {
            p_y1 = element->bodyHitbox->y + (P_CROUCH_HEIGHT / 2);
            k_y1 = element->bodyHitbox->y + (P_CROUCH_HEIGHT / 2);
        }
        else {
            p_y1 = element->bodyHitbox->y;
            if (element->isCrouch)
                k_y1 = element->bodyHitbox->y;
            else
                k_y1 = element->bodyHitbox->y + P_CROUCH_HEIGHT;
        }

        // decisão da posição x1 do ataque
        if (element->facing == 0)
            element->atkHitbox->x = element->bodyHitbox->x + element->bodyHitbox->width;   
        else
            element->atkHitbox->x = element->bodyHitbox->x;

        // inicialização da hitbox de ataque
        if (element->action->light_punch || element->action->hard_punch) {
            element->atkHitbox->y = p_y1;
            element->atkHitbox->height = PUNCH_H;
            if (element->action->light_punch)
                element->atkHitbox->width = L_PUNCH_W;
            else
                element->atkHitbox->width = H_PUNCH_W;
        }
        else if (element->action->light_kick || element->action->hard_kick) {
            element->atkHitbox->y = k_y1;
            element->atkHitbox->height = KICK_H;
            if (element->action->light_kick)
                element->atkHitbox->width = L_KICK_W;
            else
                element->atkHitbox->width = H_KICK_W;
        }
        element->atkHitboxTick = ATK_TICK;
    }
    else
        element->atkHitboxTick--;
}

void insertComboKey (player *p, int keycode) {
    if (p->comboIndex < MAX_COMBO_KEY) {
        p->combo[p->comboIndex] = keycode;
        p->comboTimeElapsed = 0;
        p->comboIndex++;

        checkCombo(p, keycode);
    }
}

void checkCombo (player *p, int keycode) {
    for (int i = 0; i < MAX_COMBO_KEY; i++)
        if (p->facing == 0) {
            if (p->combo[i] == COMBO_SEQUENCES_0[p->character_id][i]) {
                if (COMBO_SEQUENCES_0[p->character_id][i + 1] == 0 && !p->comboCooldown) {
                    p->comboSuccess = p->character_id + 1;
                    return;
                }
            }
            else
                break;
        }
        else {
            if (p->combo[i] == COMBO_SEQUENCES_1[p->character_id][i]) {
                if (COMBO_SEQUENCES_1[p->character_id][i + 1] == 0 && !p->comboCooldown) {
                    p->comboSuccess = p->character_id + 1;
                    return;
                }
            }
            else
                break;
        }

    p->comboSuccess = 0;
}

void updateCombo (player *p1, player *p2) {
    if ((p1->comboTimeElapsed < COMBO_TIME_LIMIT ) && (p1->comboIndex < MAX_COMBO_KEY))
        p1->comboTimeElapsed++;
    else {
        for (int i = 0; i < MAX_COMBO_KEY; i++)
            p1->combo[i] = 0;
        p1->comboIndex = 0;
        p1->comboSuccess = 0;
    }

    if ((p2->comboTimeElapsed < COMBO_TIME_LIMIT ) && (p2->comboIndex < MAX_COMBO_KEY))
        p2->comboTimeElapsed++;
    else {
        for (int i = 0; i < MAX_COMBO_KEY; i++)
            p2->combo[i] = 0;
        p2->comboIndex = 0;
        p2->comboSuccess = 0;
    }
}

void playerAction (player *p1, player *p2, unsigned char action) {
    switch (action) {
        // // // //
        // player 1
        case 0: // cima (ativado apenas se o player estiver onGround e em pé)
            if (p1->airStun == 0 && !p1->isAnimating) {
                if (p1->action->left) {
                    if (p1->facing == 0)
                        p1->currentAnimation = JUMP_BACKWARD;
                    else
                        p1->currentAnimation = JUMP_FORWARD;
                    p1->airStun = -JUMP_STUN;
                }
                else if (p1->action->right) {
                    if (p1->facing == 0)
                        p1->currentAnimation = JUMP_FORWARD;
                    else
                        p1->currentAnimation = JUMP_BACKWARD;
                    p1->airStun = JUMP_STUN;
                }
                else
                    p1->currentAnimation = JUMP;
            }
            if (!p1->isCrouch) {
                if (p1->onGround) {
                    p1->onGround = 0;
                    p1->vy = -JUMP_VEL;
                }
            }
            break;
            
        case 1: // esquerda
            if (!p1->isCrouch && !p1->atkHitboxTick) {
                p1->currentAnimation = WALKING;
                p1->vx = -MOVE_STEP;
                if (checkWallCollision(p1))
                    p1->bodyHitbox->x = 0;
                else if (checkPlayerCollision(p1, p2)) {
                    if (checkWallCollision(p2) && (p1->bodyHitbox->x < X_SCREEN/2)) {
                        p2->bodyHitbox->x = 0;
                        p1->bodyHitbox->x = (p1->bodyHitbox->width) + 5;
                    }
                    else {
                        p2->vx = p1->vx + 7;
                        if (checkWallCollision(p2) && (p1->bodyHitbox->x < X_SCREEN/2)) {
                            p2->bodyHitbox->x = 0;
                            p1->bodyHitbox->x = (p1->bodyHitbox->width) + 5;
                        } else {
                            p2->bodyHitbox->x += p2->vx;
                            p1->bodyHitbox->x += p1->vx + 7;
                        }
                    }
                }
                else {
                    p1->bodyHitbox->x += p1->vx;
                }
                p2->vx = 0;
                p1->vx = 0;
            }
            break;
            
        case 2: // baixo
            if (p1->isCrouch == 1) {
                if (!p1->isAnimating)
                    p1->currentAnimation = CROUCH;
                p1->bodyHitbox->height = P_CROUCH_HEIGHT;
            }
            else
                p1->bodyHitbox->height = P_HEIGHT;
            
            p1->bodyHitbox->y = Y_GROUND - p1->bodyHitbox->height;
            break;
            
        case 3: // direita
            if (!p1->isCrouch && !p1->atkHitboxTick) {
                p1->currentAnimation = WALKING;
                p1->vx = MOVE_STEP;
                if (checkWallCollision(p1))
                    p1->bodyHitbox->x = X_SCREEN - p1->bodyHitbox->width;
                else if (checkPlayerCollision(p1, p2)) {
                    if (checkWallCollision(p2) && (p1->bodyHitbox->x > X_SCREEN/2)) {
                        p2->bodyHitbox->x = X_SCREEN - p2->bodyHitbox->width;
                        p1->bodyHitbox->x = X_SCREEN - (p1->bodyHitbox->width * 2) - 5;
                    }
                    else {
                        p2->vx = p1->vx - 7;
                        p2->bodyHitbox->x += p2->vx;
                        p1->bodyHitbox->x += p1->vx - 7;
                    }
                }
                else {
                    p1->bodyHitbox->x += p1->vx;
                }
                p1->vx = 0;
                p2->vx = 0;
            }
            break;
            
        case 4: // light punch
            setAtkHitbox (p1);
            if (p1->isCrouch)
                p1->currentAnimation = CROUCH_LPUNCH;
            else if (!p1->onGround) 
                p1->currentAnimation = JUMP_PUNCH;
            else
                p1->currentAnimation = LPUNCH;
            p1->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown (p1);
                p2->isDamaged += L_PUNCH_DAM;
            }
            break;

        case 5: // hard punch
            setAtkHitbox (p1);
            if (p1->isCrouch)
                p1->currentAnimation = CROUCH_HPUNCH;
            else if (!p1->onGround) 
                p1->currentAnimation = JUMP_PUNCH;
            else
                p1->currentAnimation = HPUNCH;
            p1->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown (p1);
                p2->isDamaged += H_PUNCH_DAM;
            }
            break;

        case 6: // light kick
            setAtkHitbox (p1);
            if (p1->isCrouch)
                p1->currentAnimation = CROUCH_LKICK;
            else if (!p1->onGround) 
                p1->currentAnimation = JUMP_KICK;
            else
                p1->currentAnimation = LKICK;
            p1->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown (p1);
                p2->isDamaged += L_KICK_DAM;
            }
            break;

        case 7: // hard kick
            setAtkHitbox (p1);
            if (p1->isCrouch)
                p1->currentAnimation = CROUCH_HKICK;
            else if (!p1->onGround) 
                p1->currentAnimation = JUMP_KICK;
            else
                p1->currentAnimation = HKICK;
            p1->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown (p1);
                p2->isDamaged += H_KICK_DAM;
            }
            break;

        // // // //
        // player 2
        case 8: // cima (ativado apenas se o player estiver onGround e em pé)
            if (p2->airStun == 0 && !p2->isAnimating) {
                if (p2->action->left) {
                    if (p2->facing == 0)
                        p2->currentAnimation = JUMP_BACKWARD;
                    else
                        p2->currentAnimation = JUMP_FORWARD;
                    p2->airStun = -JUMP_STUN;
                }
                else if (p2->action->right) {
                    if (p2->facing == 0)
                        p2->currentAnimation = JUMP_FORWARD;
                    else
                        p2->currentAnimation = JUMP_BACKWARD;
                    p2->airStun = JUMP_STUN;
                }
                else
                    p2->currentAnimation = JUMP;
            }
            if (!p2->isCrouch) {
                if (p2->onGround) {
                    p2->onGround = 0;
                    p2->vy = -JUMP_VEL;
                }
            }
            break;
            
        case 9: // esquerda
            if (!p2->isCrouch && !p2->atkHitboxTick) {
                p2->currentAnimation = WALKING;
                p2->vx = -MOVE_STEP;
                if (checkWallCollision(p2))
                    p2->bodyHitbox->x = 0;
                else if (checkPlayerCollision(p2, p1)) {
                    if (checkWallCollision(p1) && (p2->bodyHitbox->x < X_SCREEN/2)) {
                        p1->bodyHitbox->x = 0;
                        p2->bodyHitbox->x = p2->bodyHitbox->width + 5;
                    }
                    else {
                        p1->vx = p2->vx + 7;
                        if (checkWallCollision(p1) && (p2->bodyHitbox->x < X_SCREEN/2)) {
                            p1->bodyHitbox->x = 0;
                            p2->bodyHitbox->x = p2->bodyHitbox->width + 5;
                        }
                        else {
                            p1->bodyHitbox->x += p1->vx;
                            p2->bodyHitbox->x += p2->vx + 7;
                        }
                    }
                }
                else {
                    p2->bodyHitbox->x += p2->vx;
                }
                p1->vx = 0;
                p2->vx = 0;
            }
            break;
            
            
        case 10: // baixo
            if (p2->isCrouch == 1) {
                if (!p2->isAnimating)
                        p2->currentAnimation = CROUCH;
                    p2->bodyHitbox->height = P_CROUCH_HEIGHT;
            }
            else
                p2->bodyHitbox->height = P_HEIGHT;

            p2->bodyHitbox->y = Y_GROUND - p2->bodyHitbox->height;
            break;
            
        case 11: // direita
            if (!p2->isCrouch && !p2->atkHitboxTick) {
                p2->currentAnimation = WALKING;
                p2->vx = MOVE_STEP;
                if (checkWallCollision(p2))
                    p2->bodyHitbox->x = X_SCREEN - p2->bodyHitbox->width;
                else if (checkPlayerCollision(p2, p1)) {
                    if (checkWallCollision(p1) && (p2->bodyHitbox->x > X_SCREEN/2)) {
                        p1->bodyHitbox->x = X_SCREEN - p1->bodyHitbox->width;
                        p2->bodyHitbox->x = X_SCREEN - (p2->bodyHitbox->width * 2) - 5;
                    }
                    else {
                        p1->vx = p2->vx - 7;
                        p1->bodyHitbox->x += p1->vx;
                        p2->bodyHitbox->x += p2->vx - 7;
                    }
                }
                else {
                    p2->bodyHitbox->x += p2->vx;
                }
                p2->vx = 0;
            }
            break;
            
        case 12: // light punch
            setAtkHitbox (p2);
            if (p2->isCrouch)
                p2->currentAnimation = CROUCH_LPUNCH;
            else if (!p2->onGround)
                p2->currentAnimation = JUMP_PUNCH;
            else
                p2->currentAnimation = LPUNCH;
            p2->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown(p2);
                p1->isDamaged += L_PUNCH_DAM;
            }
            break;

        case 13: // hard punch
            setAtkHitbox (p2);
            if (p2->isCrouch)
                p2->currentAnimation = CROUCH_HPUNCH;
            else if (!p2->onGround)
                p2->currentAnimation = JUMP_PUNCH;
            else
                p2->currentAnimation = HPUNCH;
            p2->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown(p2);
                p1->isDamaged += H_PUNCH_DAM;
            }
            break;

        case 14: // light kick
            setAtkHitbox (p2);
            if (p2->isCrouch)
                p2->currentAnimation = CROUCH_LKICK;
            else if (!p2->onGround)
                p2->currentAnimation = JUMP_KICK;
            else
                p2->currentAnimation = LKICK;
            p2->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown(p2);
                p1->isDamaged += L_KICK_DAM;
            }
            break;

        case 15: // hard kick
            setAtkHitbox (p2);
            if (p2->isCrouch)
                p2->currentAnimation = CROUCH_HKICK;
            else if (!p2->onGround)
                p2->currentAnimation = JUMP_KICK;
            else
                p2->currentAnimation = HKICK;
            p2->isAnimating = 1;
            if(checkAtkHit(p1, p2)) {
                setAtkCooldown(p2);
                p1->isDamaged += H_KICK_DAM;
            }
            break;
    }
    
    // checkAtkHit (p1, p2);
}

void playerDestroy (player *element) {
    if (element) {
        joystickDestroy (element->action);
        hitboxDestroy (element->bodyHitbox);
        hitboxDestroy (element->atkHitbox);
        free (element->combo);
    }
    free (element);
}