#include <stdio.h>
#include <allegro5/allegro5.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>

#include "player.h"
#include "gameinfo.h"
#include "menu.h"


void updateAnimation (player *p1, player *p2) {
    animation *p1_anim = &p1->playerAnimation[p1->currentAnimation];
    animation *p2_anim = &p2->playerAnimation[p2->currentAnimation];
    if(p1->isDamaged)
        p1->currentAnimation = HIT;

    if (p1_anim->frameDelayCounter < p1_anim->frameDelay) {
        p1_anim->frameDelayCounter++;
    }
    else {
        p1_anim->frameDelayCounter = 0;

        if (p1->currentAnimation != WIN || p1->currentAnimation != LOSE) {
            p1->isAnimating = 0;
        }
        else
            return;

        if (!p1->atkHitboxTick && 
            !p1->action->left && 
            !p1->action->right && 
            p1->onGround &&
            !p1->isCrouch &&
            !p1->comboCooldown)
            p1->currentAnimation = IDLE;
            
        if (p1->isDamaged)
            p1->currentAnimation = HIT;

        if (p1_anim->currentFrame+1 < p1_anim->numFrames)
            p1_anim->currentFrame++;
        else
            p1_anim->currentFrame = 0;
    }

    if(p2->isDamaged)
        p2->currentAnimation = HIT;

    if (p2_anim->frameDelayCounter < p2_anim->frameDelay) {
        p2_anim->frameDelayCounter++;
    }
    else {
        p2_anim->frameDelayCounter = 0;
        if (p2->currentAnimation != WIN || p2->currentAnimation != LOSE){
            p2->isAnimating = 0;
        }
        else
            return;

        if (!p2->atkHitboxTick && 
            !p2->action->left && 
            !p2->action->right && 
            p2->onGround &&
            !p2->isCrouch &&
            !p2->comboCooldown)
            p2->currentAnimation = IDLE;

        if (p2->isDamaged)
            p2->currentAnimation = HIT;

        if (p2_anim->currentFrame+1 < p2_anim->numFrames)
            p2_anim->currentFrame++;
        else
            p2_anim->currentFrame = 0;
    }
}

void updatePlayer (player *p1, player *p2) {
    if (!p1->onGround || p1->isCrouch) {
        p1->bodyHitbox->height = P_CROUCH_HEIGHT; 
        if (p1->onGround)
            p1->bodyHitbox->y = Y_GROUND - p1->bodyHitbox->height;
    }
    else
        p1->bodyHitbox->height = P_HEIGHT;

    if (!p2->onGround || p2->isCrouch) {
        p2->bodyHitbox->height = P_CROUCH_HEIGHT; 
        if (p2->onGround)
            p2->bodyHitbox->y = Y_GROUND - p2->bodyHitbox->height;
    }
    else
        p2->bodyHitbox->height = P_HEIGHT;

    if (!checkComboHit(p1, p2)) {
        if (p1->action->up) {
            playerAction(p1, p2, 0);
            toggleState(&p1->action->up);
        } 
        if (p1->action->left) {
            if (p1->onGround)
                playerAction(p1, p2, 1);
        }
        if (p1->action->down) {
            if (p1->onGround)
                playerAction(p1, p2, 2);
        }
        if (p1->action->right) {
            if (p1->onGround)
                playerAction(p1, p2, 3);
        }
        if (p1->action->light_punch) {
            playerAction(p1, p2, 4);
            toggleState(&p1->action->light_punch);
        }
        if (p1->action->hard_punch) {
            playerAction(p1, p2, 5);
            toggleState(&p1->action->hard_punch);
        }
        if (p1->action->light_kick) {
            playerAction(p1, p2, 6);
            toggleState(&p1->action->light_kick);
        }
        if (p1->action->hard_kick) {
            playerAction(p1, p2, 7);
            toggleState(&p1->action->hard_kick);
        }
    }
    
    if (!checkComboHit(p1, p2)) {
        if (p2->action->up) {
            playerAction(p1, p2, 8);
            toggleState(&p2->action->up);
        } 
        if (p2->action->left) {
            if (p2->onGround)
                playerAction(p1, p2, 9);
        }
        if (p2->action->down) {
            if (p2->onGround)
                playerAction(p1, p2, 10);
        }
        if (p2->action->right) {
            if (p2->onGround)
                playerAction(p1, p2, 11);
        }
        if (p2->action->light_punch) {
            playerAction(p1, p2, 12);
            toggleState(&p2->action->light_punch);
        }
        if (p2->action->hard_punch) {
            playerAction(p1, p2, 13);
            toggleState(&p2->action->hard_punch);
        }
        if (p2->action->light_kick) {
            playerAction(p1, p2, 14);
            toggleState(&p2->action->light_kick);
        }
        if (p2->action->hard_kick) {
            playerAction(p1, p2, 15);
            toggleState(&p2->action->hard_kick);
        }
    }
}

void processKeyboard (int keycode, player *p1, player *p2, int eventType, gameStatus *gameStatus, menu *menu) {
    if (gameStatus->gameScene == 0 && (eventType == ALLEGRO_EVENT_KEY_DOWN)) {
        if (keycode == ALLEGRO_KEY_W ||
            keycode == ALLEGRO_KEY_S ||
            keycode == 85 ||
            keycode == 84)
            menu->option = !menu->option;

        else if (keycode == ALLEGRO_KEY_ENTER)
            if (menu->option == 1)
                menu->close = 1;
            else {
                menu->option = 0;
                gameStatus->gameScene++;
            }
    }

    else if (gameStatus->gameScene == 1 && (eventType == ALLEGRO_EVENT_KEY_DOWN)) { 
        switch (keycode) {
            case ALLEGRO_KEY_A:
                if (menu->p1_CharConfirmed == 0) {
                    if (p1->character_id == 0)
                        p1->character_id = 3;
                    else
                        p1->character_id--;
                }
                break;
    
            case ALLEGRO_KEY_D:
                if (menu->p1_CharConfirmed == 0) {
                    if (p1->character_id == 3)
                        p1->character_id = 0;
                    else
                        p1->character_id++;
                }
                break;

            case 82:
                if (menu->p2_CharConfirmed == 0) {
                    if (p2->character_id == 4)
                        p2->character_id = 7;
                    else
                        p2->character_id--;
                }
                break;
                
            case 83:
                if (menu->p2_CharConfirmed == 0) {
                    if (p2->character_id == 7)
                        p2->character_id = 4;
                    else
                        p2->character_id++;
                }
                break;
        }
        if (keycode == ALLEGRO_KEY_J || 
            keycode == ALLEGRO_KEY_U ||
            keycode == ALLEGRO_KEY_I ||
            keycode == ALLEGRO_KEY_K)
            menu->p1_CharConfirmed = 1;

        if (keycode == ALLEGRO_KEY_PAD_2 || 
            keycode == ALLEGRO_KEY_PAD_3 ||
            keycode == ALLEGRO_KEY_PAD_5 ||
            keycode == ALLEGRO_KEY_PAD_6)
            menu->p2_CharConfirmed = 1;
    }
    
    else if (gameStatus->gameScene == 2 && (eventType == ALLEGRO_EVENT_KEY_DOWN)) {
        if (keycode == ALLEGRO_KEY_D || 
            keycode == 83)
            if (menu->option == 2)
                menu->option = 0;
            else
                menu->option++;

        if (keycode == ALLEGRO_KEY_A || 
            keycode == 82)
            if (menu->option == 0)
                menu->option = 2;
            else
                menu->option--;

                
        if (keycode == ALLEGRO_KEY_ENTER)
            menu->mapConfirmed = 1;
    }

    else if (gameStatus->gameScene == 4){
        switch (keycode) {
            // player 1
            case ALLEGRO_KEY_A:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN)
                    insertComboKey(p1, ALLEGRO_KEY_A);

                joystickLeft(p1->action);
                break;

            case ALLEGRO_KEY_W:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_W);
                    joystickUp(p1->action);
                }
                break;
    
            case ALLEGRO_KEY_S:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_S);
                }

                joystickDown(p1->action);
                toggleState(&p1->isCrouch);
                break;

            case ALLEGRO_KEY_D:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN)
                    insertComboKey(p1, ALLEGRO_KEY_D);

                joystickRight(p1->action);
                break;
            
            case ALLEGRO_KEY_U:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_U);

                    if (p1->atkCooldown == 0) 
                        joystickLightPunch(p1->action);
                }
                break;
            
            case ALLEGRO_KEY_I:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_I);

                    if (p1->atkCooldown == 0) 
                        joystickHardPunch(p1->action);
                }
                break;

            case ALLEGRO_KEY_J:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_J);

                    if (p1->atkCooldown == 0) 
                        joystickLightKick(p1->action);
                }
                break;
            
            case ALLEGRO_KEY_K:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p1, ALLEGRO_KEY_K);

                    if (p1->atkCooldown == 0) 
                        joystickHardKick(p1->action);
                }
                break;


            // player 2
            case 82: // left arrow
                if (eventType == ALLEGRO_EVENT_KEY_DOWN)
                    insertComboKey(p2, 82);
                joystickLeft(p2->action);
                break;

            case 84: // up arrow
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p2, 84);
                    joystickUp(p2->action);
                }
                break;

            case 85: // down arrow
                if (eventType == ALLEGRO_EVENT_KEY_DOWN)
                    insertComboKey(p2, 85);
                joystickDown(p2->action);
                toggleState(&p2->isCrouch);
                break;

            case 83: // right arrow
                if (eventType == ALLEGRO_EVENT_KEY_DOWN)
                    insertComboKey(p2, 83);
                joystickRight(p2->action);
                break;
            
            case ALLEGRO_KEY_PAD_5:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p2, ALLEGRO_KEY_PAD_5);

                    if (p2->atkCooldown == 0) 
                        joystickLightPunch(p2->action);
                }
                break;
            
            case ALLEGRO_KEY_PAD_6:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p2, ALLEGRO_KEY_PAD_6);

                    if (p2->atkCooldown == 0) 
                        joystickHardPunch(p2->action);
                }
                break;

            case ALLEGRO_KEY_PAD_2:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p2, ALLEGRO_KEY_PAD_2);

                    if (p2->atkCooldown == 0) 
                        joystickLightKick(p2->action);
                }
                break;
            
            case ALLEGRO_KEY_PAD_3:
                if (eventType == ALLEGRO_EVENT_KEY_DOWN) {
                    insertComboKey(p2, ALLEGRO_KEY_PAD_3);

                    if (p2->atkCooldown == 0) 
                        joystickHardKick(p2->action);
                }
                break;
        }
    }
    else if (gameStatus->gameScene == 5) {
        if (eventType == ALLEGRO_EVENT_KEY_DOWN && keycode == ALLEGRO_KEY_ENTER)
            if (gameStatus->endGame == 0) {
                resetRound(p1,p2);
                gameStatus->gameScene = 4;
            }
            else
                gameStatus->gameScene = 6;
    }

    else if (gameStatus->gameScene == 6) {
        if (eventType == ALLEGRO_EVENT_KEY_DOWN)
            gameStatus->gameScene = 7;
    }
}

void drawPlayer (player *p, unsigned char enableHitbox) {
    if (!p->playerAnimation) {
        fprintf(stderr, "Failed to allocate memory for animation frames.\n");
        exit(1);
    }
    ALLEGRO_COLOR cor;
    ALLEGRO_COLOR ciano = al_map_rgb(0,255,255);

    if (p->character_id == 0 || p->character_id == 4)
        cor = al_map_rgb (0,255,0);
    else if (p->character_id == 1 || p->character_id == 5)
        cor = al_map_rgb (0,0,255);
    else if (p->character_id == 2 || p->character_id == 6)
        cor = al_map_rgb (255,0,0);
    else
        cor = al_map_rgb (255,255,255); 

    animation *pAnim = &p->playerAnimation[p->currentAnimation];
    if (!pAnim->frames || pAnim->currentFrame < 0 || pAnim->currentFrame >= pAnim->numFrames) {
        fprintf(stderr, "Erro: frames da animação são nulos ou o índice do frame atual é inválido.\n");
        return;
    }

    ALLEGRO_BITMAP *currentFrame = pAnim->frames[pAnim->currentFrame];
    if (!currentFrame) {
        fprintf(stderr, "Erro: o bitmap do frame atual é nulo.\n");
        return;
    }
    float frameW = al_get_bitmap_width(currentFrame);
    float frameH = al_get_bitmap_height(currentFrame);

    float scale = p->bitmapScale * 1.25;
    float x = p->bodyHitbox->x;
    float y;
    float pH = (p->isCrouch) ? P_CROUCH_HEIGHT : P_HEIGHT;
    if (pH > (frameH * scale))
        y = p->bodyHitbox->y;
    else y = p->bodyHitbox->y - ((frameH*scale) - pH);

    if (p->facing == 0) {
        al_draw_scaled_bitmap(currentFrame, 0, 0, frameW, frameH, x, y, frameW*scale, frameH*scale, 0);
    } else {
        al_draw_scaled_bitmap(currentFrame, 0, 0, frameW, frameH, x+p->bodyHitbox->width, y, -frameW*scale, frameH*scale, 0);
    }

    if (enableHitbox) {
        // desenho da linha do chão
        al_draw_rectangle(0, Y_GROUND + 2, X_SCREEN, Y_GROUND + 2, al_map_rgb(255,0,0), 1); 

        // desenho do player
        al_draw_rectangle(p->bodyHitbox->x, p->bodyHitbox->y, p->bodyHitbox->x + p->bodyHitbox->width, p->bodyHitbox->y + p->bodyHitbox->height, cor, 2);

        // linha vertical no meio do eixo x do jogador
        al_draw_rectangle(p->bodyHitbox->x + p->bodyHitbox->width/2, p->bodyHitbox->y, p->bodyHitbox->x + p->bodyHitbox->width/2, p->bodyHitbox->y + p->bodyHitbox->height, ciano, 2);

        // desenho dos ataques e do olho do jogador
        if (p->facing == 0) {
            if (p->atkHitboxTick)
                al_draw_rectangle(p->atkHitbox->x, p->atkHitbox->y, p->atkHitbox->x + p->atkHitbox->width, p->atkHitbox->y + p->atkHitbox->height, cor, 2);
            if (p->comboCooldown)
                al_draw_rectangle(p->comboHitbox->x, p->comboHitbox->y, p->comboHitbox->x + p->comboHitbox->width, p->comboHitbox->y + p->comboHitbox->height, cor, 2);
            al_draw_rectangle(p->bodyHitbox->x + p->bodyHitbox->width - 5, p->bodyHitbox->y + 20, p->bodyHitbox->x + p->bodyHitbox->width - 1, p->bodyHitbox->y + 30, cor, 2);
        }
        else {
            if (p->atkHitboxTick)
                al_draw_rectangle(p->atkHitbox->x, p->atkHitbox->y, p->atkHitbox->x - p->atkHitbox->width, p->atkHitbox->y + p->atkHitbox->height, cor, 2);
            if (p->comboCooldown)
                al_draw_rectangle(p->comboHitbox->x, p->comboHitbox->y, p->comboHitbox->x - p->comboHitbox->width, p->comboHitbox->y + p->comboHitbox->height, cor, 2);
            al_draw_rectangle(p->bodyHitbox->x + 1, p->bodyHitbox->y + 20, p->bodyHitbox->x + 5, p->bodyHitbox->y + 30, cor, 2);
        }
    }
}

int main () {
    al_init();
    al_init_primitives_addon();
    al_init_image_addon();
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_keyboard();

    ALLEGRO_TIMER *timer = al_create_timer (1.0 / 30.0);
    ALLEGRO_EVENT_QUEUE* queue = al_create_event_queue();
	ALLEGRO_DISPLAY* disp = al_create_display(X_SCREEN, Y_SCREEN);

    al_register_event_source(queue, al_get_keyboard_event_source());
	al_register_event_source(queue, al_get_display_event_source(disp));
	al_register_event_source(queue, al_get_timer_event_source(timer));

    player *p1 = playerCreate(INIT_X1_POS, Y_GROUND-P_HEIGHT, P_WIDTH, P_HEIGHT);
    player *p2 = playerCreate(INIT_X2_POS, Y_GROUND-P_HEIGHT, P_WIDTH, P_HEIGHT);
    gameStatus *gameStatus = gameStatusCreate();

    gameStatus->font = al_load_ttf_font("./pixelFont.ttf", 15, 0);
    gameStatus->TitleImg = al_load_bitmap("./img/title.jpg");

    menu *menu = menuCreate();

    int ignore = 0;

    // inicialização padrão do player2
    p2->character_id = 5;
    p2->facing = 1;
    p2->isHuman = 0;

    ALLEGRO_EVENT event;

	al_start_timer(timer);
    
    al_set_blender(ALLEGRO_ADD, ALLEGRO_ALPHA, ALLEGRO_INVERSE_ALPHA);

    while (1) {
        al_wait_for_event(queue, &event);
        if (menu->close)
            break;

        if (event.type == ALLEGRO_EVENT_TIMER) {
            if (gameStatus->gameScene == 0)
                runMainMenu(menu, gameStatus);
            
            else if(gameStatus->gameScene == 1) {
                al_clear_to_color(al_map_rgb(0,0,100));
                runCharSelecMenu(p1, p2, menu, gameStatus);
            }
            else if (gameStatus->gameScene == 2) {
                al_clear_to_color(al_map_rgb(0,0,100));
                runMapSelecMenu(menu, gameStatus);
            }
            else if (gameStatus->gameScene == 3) {
                al_clear_to_color(al_map_rgb(0,0,0));
                al_draw_text (gameStatus->font, al_map_rgb(255,255,255), 100, Y_SCREEN - 100, ALLEGRO_ALIGN_CENTRE, "Carregando...");
                al_flip_display();
                if (!ignore) {
                    loadPlayersChar (p1);
                    loadPlayersChar (p2);
                }
                gameStatus->gameScene++;
            }
            else if (gameStatus->gameScene == 4){
                drawBG(gameStatus);

                updateGravity(p1);
                updateGravity(p2);

                updateJump(p1, p2);
                updatePlayer(p1, p2);
                updateAnimation(p1, p2);
                updateFacing(p1, p2);

                separatePlayers(p1, p2);
                
                updateAtkHitbox(p1, p2);
                updateAtkCooldown(p1);
                updateAtkCooldown(p2);

                updateCombo(p1, p2);
                updateComboHitbox(p1, p2);
                updateComboCooldown(p1);
                updateComboCooldown(p2);

                drawPlayer(p1, 0);
                drawPlayer(p2, 0);
                updateLifeBar(p1, p2);
                if (p1->hp <= 0 || p2->hp <= 0) {
                    if (p1->hp > 0)
                        p1->roundWin++;
                    else
                        p2->roundWin++;
                    gameStatus->gameScene = 5;
                }
            }
            else if (gameStatus->gameScene == 5 && (ignore != 0 && ignore != 2)) {
                drawBG(gameStatus);
                updateJump(p1, p2);
                updatePlayer(p1, p2);
                updateAnimation(p1, p2);
                updateGravity(p1);
                updateGravity(p2);
                drawPlayer(p1, 0);
                drawPlayer(p2, 0);
                drawLifeBar(p1, p2);
                al_draw_text (gameStatus->font, al_map_rgb(255,255,255), X_SCREEN/2 +2, Y_SCREEN/2, ALLEGRO_ALIGN_CENTRE, "ENTER para continuar");
            }
            else if(gameStatus->gameScene == 6) {
                runEndGame(p1, p2);
            }
            else if(gameStatus->gameScene == 7) {
                break;
            }
            if (gameStatus->gameScene == 5)
                ignore++;
            if (p1->roundWin == 2 || p2->roundWin == 2)
                    gameStatus->endGame = 1;
                else
                    gameStatus->endGame = 0;
            al_flip_display();
        }
        else if (event.type == ALLEGRO_EVENT_KEY_DOWN || event.type == ALLEGRO_EVENT_KEY_UP) {
            if (event.keyboard.keycode == ALLEGRO_KEY_ESCAPE)
                break;
        
            processKeyboard (event.keyboard.keycode, p1, p2, event.type, gameStatus, menu);
        }
    }

    al_destroy_font(gameStatus->font);
    al_destroy_display(disp);
    al_destroy_timer(timer);
    al_destroy_event_queue(queue);
    gameStatusDestroy(gameStatus);
    menuDestroy(menu);
    playerDestroy(p1);

    return 0;
}