#ifndef __MENU__
#define __MENU__

typedef struct {
    unsigned char option;
    unsigned char close;
    unsigned char switchImgTitle;
    unsigned char switchP1_box;
    unsigned char switchP2_box;
    unsigned char switchMap;
    unsigned char p1_CharConfirmed;
    unsigned char p2_CharConfirmed;
    unsigned char mapsPlaced;
    unsigned char mapConfirmed;
    ALLEGRO_BITMAP *ryuMenu;
    ALLEGRO_BITMAP *chunliMenu;
    ALLEGRO_BITMAP *blankaMenu;
    ALLEGRO_BITMAP *zangiefMenu;
} menu;

menu *menuCreate();
void runMainMenu(menu *menu, gameStatus *gameStatus);
void runCharSelecMenu(player *p1, player *p2, menu *menu, gameStatus *gameStatus);
void runMapSelecMenu(menu *menu, gameStatus *gameStatus);
void runEndGame (player *p1, player *p2);
void menuDestroy(menu *menu);

#endif